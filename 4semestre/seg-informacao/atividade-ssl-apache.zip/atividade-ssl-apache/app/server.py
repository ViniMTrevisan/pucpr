#!/usr/bin/env python3
"""
Backend simples para o Desafio 3.
Roda na porta 80 (HTTP) para que o Wireshark capture o payload em claro.

Uso:
    sudo python3 server.py

Acesse: http://<IP-DA-VM>/
"""

import http.server
import urllib.parse
import json
import os
from datetime import datetime

PORT = 80
STORAGE_FILE = "/tmp/form_data.txt"
STATIC_DIR = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.BaseHTTPRequestHandler):

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {fmt % args}")

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._serve_file("index.html", "text/html; charset=utf-8")
        else:
            self._not_found()

    def do_POST(self):
        if self.path == "/submit":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length).decode("utf-8")
            params = urllib.parse.parse_qs(body)

            line = (
                f"[{datetime.now().isoformat()}] "
                + " | ".join(f"{k}={v[0]}" for k, v in params.items())
                + "\n"
            )
            with open(STORAGE_FILE, "a") as f:
                f.write(line)

            print(f"  DADOS RECEBIDOS: {line.strip()}")

            self._json({"status": "ok", "saved": STORAGE_FILE})
        else:
            self._not_found()

    def _serve_file(self, filename, content_type):
        path = os.path.join(STATIC_DIR, filename)
        try:
            with open(path, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", len(data))
            self.end_headers()
            self.wfile.write(data)
        except FileNotFoundError:
            self._not_found()

    def _json(self, obj):
        data = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    def _not_found(self):
        self.send_response(404)
        self.end_headers()


if __name__ == "__main__":
    print(f"Servidor HTTP rodando na porta {PORT}...")
    print(f"Dados salvos em: {STORAGE_FILE}")
    print("Use Ctrl+C para parar.\n")
    with http.server.HTTPServer(("", PORT), Handler) as srv:
        srv.serve_forever()
