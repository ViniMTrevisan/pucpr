#!/bin/bash
set -e

echo "==> Atualizando repositórios..."
apt update -y

echo "==> Instalando apache2 e openssl..."
apt install -y apache2 openssl

echo "==> Gerando chave privada e certificado autoassinado..."
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/apache-selfsigned.key \
  -out /etc/ssl/certs/apache-selfsigned.crt \
  -subj "/C=BR/ST=Parana/L=Curitiba/O=PUC-PR/CN=Ubuntu SSL"

echo "==> Ajustando permissões..."
chmod 600 /etc/ssl/private/apache-selfsigned.key
chmod 644 /etc/ssl/certs/apache-selfsigned.crt

echo "==> Configurando default-ssl.conf..."
SSL_CONF="/etc/apache2/sites-available/default-ssl.conf"

sed -i 's|SSLCertificateFile\s.*|SSLCertificateFile /etc/ssl/certs/apache-selfsigned.crt|' "$SSL_CONF"
sed -i 's|SSLCertificateKeyFile\s.*|SSLCertificateKeyFile /etc/ssl/private/apache-selfsigned.key|' "$SSL_CONF"

echo "==> Habilitando módulo SSL e site default-ssl..."
a2enmod ssl
a2ensite default-ssl

echo "==> Reiniciando Apache..."
systemctl restart apache2

echo ""
echo "==> Concluído. Acesse: https://localhost"
echo "    Certificado : /etc/ssl/certs/apache-selfsigned.crt"
echo "    Chave       : /etc/ssl/private/apache-selfsigned.key"
