# Atividade SSL/Apache — PUCPR Segurança da Informação

## Estrutura de arquivos

```
atividade-ssl-apache/
├── setup_apache_ssl.sh   # Script principal (Partes 1 e 2)
├── app/
│   ├── index.html        # Formulário HTML (Desafio 3)
│   └── server.py         # Backend Python HTTP (Desafio 3)
└── INSTRUCOES.md
```

---

## Parte 1 — Executar o script de configuração SSL

Na VM Ubuntu 22.04, como root:

```bash
chmod +x setup_apache_ssl.sh
sudo ./setup_apache_ssl.sh
```

O script faz:
1. `apt update`
2. Instala `apache2` e `openssl`
3. Gera chave RSA 2048 bits + certificado X.509 autoassinado (365 dias)
   - Chave  → `/etc/ssl/private/apache-selfsigned.key`
   - Cert   → `/etc/ssl/certs/apache-selfsigned.crt`
   - Dados: C=BR, ST=Parana, L=Curitiba, O=PUC-PR, CN=Ubuntu SSL
4. Edita `/etc/apache2/sites-available/default-ssl.conf`
5. Habilita `mod_ssl` e o virtual host `default-ssl`
6. Reinicia o Apache

Verificar se está funcionando:
```bash
curl -k https://localhost
```

---

## Parte 2 — Wireshark

### Abrir o Wireshark como root

```bash
# Opção 1 — direto pelo terminal
sudo wireshark

# Opção 2 — sem precisar digitar senha toda vez (adiciona usuário ao grupo)
sudo usermod -aG wireshark $USER
# (fazer logout/login depois)
wireshark
```

### Filtros de captura

| Objetivo | Expressão de filtro |
|---|---|
| Somente porta 80 (HTTP — texto claro) | `tcp.port == 80` |
| Somente porta 443 (HTTPS — criptografado) | `tcp.port == 443` |
| Apenas requisições HTTP POST (payload visível) | `http.request.method == "POST"` |
| Ver conteúdo do formulário em claro | `tcp.port == 80 and http` |
| Comparar as duas portas ao mesmo tempo | `tcp.port == 80 or tcp.port == 443` |

> **Dica**: para ver o payload em texto claro no HTTP, clique com o botão direito
> no pacote → *Follow* → *TCP Stream*.

---

## Desafio 3 — Aplicação Web para captura de payload

### Objetivo
Enviar dados de formulário **sem criptografia (HTTP, porta 80)** para que o
Wireshark capture o payload legível.

### Subir o servidor Python (porta 80)

```bash
cd app/
sudo python3 server.py
```

Acesse no navegador da VM: `http://localhost/`

### O que capturar no Wireshark
1. Inicie a captura na interface `lo` (loopback) ou na interface de rede da VM.
2. Filtro: `tcp.port == 80 and http`
3. Preencha o formulário e clique em **Enviar**.
4. No Wireshark, localize o pacote `POST /submit HTTP/1.1`.
5. Expanda *Hypertext Transfer Protocol* → *HTML Form URL Encoded*.
   - Você verá os campos `usuario`, `senha` e `mensagem` em **texto claro**.

### Comparação HTTP vs HTTPS
| | HTTP (porta 80) | HTTPS (porta 443) |
|---|---|---|
| Filtro Wireshark | `tcp.port == 80` | `tcp.port == 443` |
| Payload visível? | **Sim** — texto claro | **Não** — TLS cifrado |
| Risco | Credenciais expostas | Protegido |

### Dados salvos no servidor
Os dados enviados ficam em `/tmp/form_data.txt` na VM.

```bash
cat /tmp/form_data.txt
```
